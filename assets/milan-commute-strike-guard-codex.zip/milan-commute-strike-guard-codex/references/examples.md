# Canonical Examples

Use these examples to keep behavior stable. They are not demo data and should not be copied when dates, sources, or user inputs differ. Preserve the decision pattern and output shape.

## Example 1: Missing Profile Gate

User:

```text
下周课表如下：
周一 10:30-12:00 Corporate Finance
周三 08:45-10:15 Italian
请帮我看下周有没有罢工
```

Correct behavior:

- Do not check MIT, ATM, Trenord, or web search yet.
- Do not output generic strike results.
- Ask only for missing commute profile fields.

Expected answer:

```text
可以，我先帮你建通勤档案。要判断罢工会不会影响你，还差这些信息：

1. 你住在哪个地铁站/街区附近？
2. 平时怎么去 Bocconi？可以发路线截图，或写成 M4 Tolstoj -> Santa Sofia -> 步行。
3. 学校默认 Bocconi 可以吗？

补完后我再查本周交通风险，给你每天几点出门、是否需要备选路线和提醒。
```

## Example 2: Low-Risk Weekly Plan

User:

```text
我家在 Tolstoj。学校默认 Bocconi。平时路线是 M4 Tolstoj -> Santa Sofia -> 步行到 Bocconi。
下周课表：
周一 10:30-12:00 Corporate Finance
周三 08:45-10:15 Italian
帮我看通勤风险、每天几点出门，并创建提醒。
```

Correct behavior:

- Re-check current transport sources before answering.
- If no relevant strike or disruption overlaps the user's route, mark risk low.
- Include one Google Maps Markdown link in every class-day card.
- Create reminders by default if automation is available.

Expected answer shape:

```text
## 本周概览

- **风险**：低
- **原因**：本周未发现影响 ATM/M4 或该路线的罢工；按平时路线通勤即可
- **来源**：MIT/ATM/辅助源已查；无相关告警

## 每日通勤

### 周一 | Corporate Finance

- **时间**：10:30-12:00
- **风险**：低
- **出门**：9:40-9:45
- **路线**：M4 Tolstoj -> Santa Sofia -> 步行到 Bocconi
- **耗时**：约 27-30 分钟
- **注意**：出发前打开地图复查实时班次即可
- **导航**：[打开 Google Maps 导航](URL)

### 周三 | Italian

- **时间**：08:45-10:15
- **风险**：低
- **出门**：7:55-8:00
- **路线**：M4 Tolstoj -> Santa Sofia -> 步行到 Bocconi
- **耗时**：约 27-30 分钟
- **注意**：早课别压线，预留等车和步行缓冲
- **导航**：[打开 Google Maps 导航](URL)

## 下一步

- 已创建本周出门提醒。
- 已创建每周日 17:00 课表提醒。
- 不需要的话可以在“自动任务”里暂停或删除。
```

## Example 3: High-Risk Strike Day

User:

```text
我家在 Tolstoj，平时坐 M4 到 Santa Sofia 再步行到 Bocconi。
周五 10:30-12:00 Corporate Finance。
如果这周有 ATM 罢工，帮我判断怎么去。
```

Correct behavior:

- If a confirmed ATM strike overlaps the user's commute time and route uses M4, mark risk high.
- Do not present M4 as the reliable recommended route unless a source states a guaranteed service window.
- Explain guaranteed windows in plain Chinese when present.
- Give non-ATM backup actions.
- Do not give normal commute time as the strike-day guarantee.
- Include Google Maps Markdown link.
- Create medium/high-risk reminders by default if automation is available.

Expected answer shape:

```text
## 本周概览

- **风险**：高
- **原因**：确认存在 ATM 罢工，且你的上课通勤依赖 M4，正好落在受影响窗口
- **来源**：MIT/ATM/辅助源已查；罢工与路线相关

## 每日通勤

### 周五 | Corporate Finance

- **时间**：10:30-12:00
- **风险**：高
- **原因**：ATM 罢工覆盖上课通勤时段，常用 M4 不稳
- **平时路线**：M4 Tolstoj -> Santa Sofia -> 步行到 Bocconi；不建议依赖
- **主方案 A**：如果公告写 8:45 前为保证服务时段，就提前坐 M4 到校，在学校附近等课
- **主方案 B**：不想早到就不要依赖 M4/tram/bus，改骑车、共享单车、打车或步行组合
- **出门**：方案 A 按保证窗口提前到校；方案 B 按实时导航多留 20-30 分钟
- **耗时**：M4 若正常约 27-30 分钟；替代方案以实时导航为准
- **注意**：tram/bus 也可能受 ATM 罢工影响，不要当作默认可靠备选
- **导航**：[打开 Google Maps 导航](URL)

## 下一步

- 已创建周五前一晚通勤提醒。
- 已创建周五出发前 2 小时复查提醒。
- 已创建周五出门提醒。
- 不需要的话可以在“自动任务”里暂停或删除。
```

## Common Failure Fixes

- If the answer starts checking strikes before asking for a missing home, route, or timetable, apply Example 1.
- If a confirmed overlapping ATM strike is labeled medium, apply Example 3 and mark it high.
- If a high-risk day still recommends the affected metro/tram/bus as the main route without a guaranteed window, apply Example 3.
- If any class-day card says `导航：同上` or omits the map link, repeat the Google Maps Markdown link in that card.
- If the answer becomes a long source report, return to the three-section output shape in Examples 2 and 3.

## Example 4: Codex Reminder Creation

User:

```text
我家在 Tolstoj。平时路线是 M4 Tolstoj -> Santa Sofia -> 步行到 Bocconi。学校默认 Bocconi。
下周课表：
周一 10:30-12:00 Corporate Finance
周三 08:45-10:15 Italian
帮我看通勤风险并创建提醒。
```

Correct behavior:

- Finish the commute plan first.
- If Codex automation tooling is available, create reminders by default.
- Do not ask "要不要创建提醒".
- Do not output a long copy-paste reminder list when reminders were actually created.

Expected `下一步` wording:

```text
## 下一步

- 已创建每周日 17:00 课表提醒。
- 已创建本周上课前一晚提醒。
- 已创建本周出门提醒。
- 不需要的话告诉我「取消通勤提醒」。
```

If automation tooling is unavailable:

```text
## 下一步

- 当前环境不能直接创建提醒。
- 我可以给你生成简短提醒文案，或按你的系统日历格式整理。
```
