# Milan Transport Sources

## Freshness Rule

For strikes, delays, suspensions, reduced service, or route availability, re-check live sources every time the user asks. Do not reuse previous answers, older search snippets, or cached conclusions as current proof.

Use Milan local time (`Europe/Rome`) for date ranges, weekdays, and "today/tomorrow/next week" judgments about Milan transport.

## Source Priority

Use this order when checking Milan commute risk:

1. MIT strike calendar  
   Calendar: `https://scioperi.mit.gov.it/mit2/public/scioperi`  
   Optional RSS: `https://scioperi.mit.gov.it/mit2/public/scioperi/rss`  
   If Marvis gets SSL/certificate errors, do not keep retrying RSS. Use the calendar page, web search, and operator sources instead.
2. ATM Milano InfoTraffico  
   `https://www.atm.it/it/ViaggiaConNoi/InfoTraffico/`
3. Trenord notices  
   `https://www.trenord.it/news/trenord-informa/avvisi/`
4. Commissione Garanzia Sciopero  
   `https://commissionegaranziasciopero.it/calendario-scioperi`
5. The Italy Strike, as a secondary summary  
   `https://www.theitalystrike.com/`
6. Web search fallback for recent news and operator notices.

The Italy Strike can be used to quickly summarize Milan strike date, affected lines, strike windows, guarantee windows, and source labels. Do not treat it as the final authority when official sources disagree.

## Runtime Notes

- Do not surface technical SSL/Python errors to students.
- If MIT cannot be read, say `MIT: 未成功读取；已改用 ATM/Trenord/Commissione/搜索结果交叉判断`.
- Do not let MIT RSS failure block the weekly commute answer.

## No-API Boundary

This skill does not require Google Maps API or any user API key. Generate Google Maps navigation links with URL parameters:

```text
https://www.google.com/maps/dir/?api=1&origin={origin}&destination={destination}&travelmode=transit
```

Use Google Maps for final real-time navigation. Use the skill for route-risk judgment, reminder timing, and "what to check before leaving."

## Filtering Rules

Flag a transport alert if it matches at least one geography term and one transport term.

Geography terms:

- `Milano`, `Milan`, `Lombardia`, `MI`, `Italia` when the sector is transport.

Operator/mode terms:

- `ATM`, `Trenord`, `TPL`, `trasporto pubblico locale`, `ferroviario`, `ferroviari`, `metro`, `metropolitana`, `tram`, `bus`, `filobus`, `Passante`, `S line`, `regionale`.

Strike/disruption terms:

- `sciopero`, `agitazione`, `astensione`, `servizio`, `interruzione`, `deviazione`, `sospensione`, `riduzione`.

## Route Matching

Extract route keywords from user text or screenshots:

- Metro lines: `M1`, `M2`, `M3`, `M4`, `M5`.
- Stations: `Romolo`, `Porta Genova`, `Centrale`, `Cadorna`, `Garibaldi`, `Duomo`, `Missori`, `Lodi`, `Porta Romana`, `Santa Sofia`, `Tolstoj`.
- Surface transit: `tram 15`, `tram 9`, `bus 90`, `bus 91`, `filobus`.
- Rail: `Trenord`, `Passante`, `S1`, `S2`, `S5`, `S6`, `S9`, `S13`, `Malpensa Express`.

Matching rules:

- Confirmed strike + affected operator/mode overlaps the user's commute date/time and normal commute mode => high risk.
- ATM strike + route contains metro/tram/bus/filobus/ATM keyword => high risk.
- ATM strike + route contains exact line keyword, such as `M4` or `tram 15` => high risk.
- Trenord/rail strike + route contains `Trenord`, `Passante`, or `S` line => high risk.
- National or regional TPL strike without exact operator/line => medium watchlist.
- No relevant date/operator/mode match => low risk.

## Practical Output Rules

- Do not claim "this route definitely runs" on a strike day unless the operator source clearly says so.
- On confirmed strike days, separate `normal route` from `recommended action`.
- If ATM is affected, do not recommend ATM tram/bus/metro as the primary backup unless a reliable source gives a guaranteed service window.
- Mention guaranteed service windows if an official or secondary source provides them.
- For low risk, use normal buffer: 15 minutes.
- For medium risk, use 30 minutes plus two-hour pre-check.
- For high risk, use 45 minutes or more plus two-hour pre-check and suggest opening Google Maps before committing to the route.
- Do not make broad season claims such as "summer strike probability is extremely low" unless backed by a source.
