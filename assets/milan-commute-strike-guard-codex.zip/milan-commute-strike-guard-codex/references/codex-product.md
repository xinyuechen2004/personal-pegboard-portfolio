# Codex Product Workflow

Use this reference when the task involves reminders, recurring checks, product behavior, or a Codex-native run.

## Product Shape

The skill is a commute-risk copilot, not a generic Milan assistant.

User gives:

- home or nearest station,
- normal route or route screenshot,
- weekly class timetable,
- destination, default Bocconi when stated.

Codex does:

- checks live Milan transport sources using Europe/Rome dates,
- judges whether each class commute is affected,
- gives a concrete route decision and Google Maps link for every class day,
- creates reminders when automation tooling is available.

## Input Gate

If any required commute field is missing, ask for the missing field first and stop. Do not check transport sources until the minimum profile is complete.

Required fields:

- home or start point,
- class timetable with weekday/date, start time, and course name,
- normal route or normal commute mode,
- destination confirmation.

## Automation Strategy

Create reminders by default after a valid weekly plan.

Default automations:

- recurring Sunday 17:00 timetable reminder,
- each class day previous-evening commute reminder,
- each class day departure reminder.

For medium/high-risk class days, also create:

- departure-minus-2-hours transport re-check reminder.

Use short notification-style text. Do not ask the user to copy reminder text manually when automation tooling is available.

## Reminder Copy

Weekly:

```text
该发下周课表啦。回到主对话上传/粘贴课表；如果住址或通勤路线有变化，也一起告诉我。
```

Previous evening:

```text
明天 {start_time} 有 {course}。风险：{risk}。建议 {departure} 前出门；出发前复查地图/ATM。
```

Two-hour risk check:

```text
今天通勤有交通风险。先查 ATM/Google Maps；如果常用线路异常，按备选方案走。
```

Departure:

```text
该准备出门了。{start_time} {course}；预计约 {duration}，出发前点开地图确认实时路线。
```

## Fallbacks

If Codex automation tooling is unavailable:

- provide compact reminder copy,
- optionally generate calendar text or `.ics` only if the user asks,
- do not pretend reminders were created.

If Google Calendar or phone push integration is unavailable:

- keep the product value centered on live risk judgment and actionable routing,
- say system-level phone calendar writing requires a calendar connector or user authorization.

## Demo And Live Use

For live use, always re-check current sources.

For a presentation demo, the user may provide an artificial scenario such as "假设本周有 ATM 罢工". Treat it as a scenario test and produce student-facing output without exposing internal demo labels, unless the user asks for transparency text.
