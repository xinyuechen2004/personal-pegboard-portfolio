---
name: milan-commute-strike-guard-codex
description: >
  ALWAYS invoke this skill when the user asks about Milan or Bocconi class commuting, weekly timetables, home-to-campus routes, ATM/Trenord/M4/metro/tram/bus strikes, sciopero, disruption, what time to leave, backup routes, or commute reminders. This skill checks current Milan transport risk, combines it with the user's timetable and normal route, then outputs departure times, route usability, Google Maps links, backup actions, and Codex reminders. Do not answer these commute-risk questions directly; use this skill first. Do NOT use this skill for bureaucracy, visa, permesso, codice fiscale, housing, restaurants, jobs, tourism, studying, or general Milan life.
---

# Milan Commute Strike Guard for Codex

## Purpose

Act as a Milan class-commute guard for Bocconi students in Codex. Combine the user's timetable, home location, normal route, and current Milan transport notices into a weekly action plan:

- which class days may be affected,
- whether the normal route is usable,
- what backup action to take on strike days,
- when to leave,
- what Codex reminders or follow-up automations to create.

Do not handle bureaucracy, pre-arrival procedures, studying, jobs, restaurant recommendations, or general Milan life. This skill has one job: class commute risk caused by Milan transport issues.

## Structure

- `SKILL.md`: trigger rules, required inputs, risk logic, output contract, and Codex reminder behavior.
- `references/transport-sources.md`: source priority, filtering rules, route matching, and freshness requirements. Read it whenever checking transport sources or judging source priority.
- `references/examples.md`: canonical examples for missing-profile, low-risk, and high-risk outputs. Read it when outputs become verbose, skip required questions, omit navigation links, or mishandle strike-day routing.
- `references/codex-product.md`: Codex product workflow, automation strategy, and fallback behavior. Read it before creating reminders or adapting the workflow beyond plain Q&A.
- `scripts/maps_link.py`: helper for Google Maps navigation URLs.
- `scripts/plan_commute.py`: helper for structured commute-plan generation.

## Invocation Cues

Use this skill when the user's message is about any of these Milan student commute situations, even if the skill name is not explicitly mentioned:

- Bocconi class commute, going to school, going home from school, or weekly timetable commute planning.
- Milan public-transport strikes or disruptions: `罢工`, `地铁停运`, `sciopero`, `strike`, `ATM`, `M4`, `metro`, `tram`, `bus`, `filobus`, `Trenord`, `Passante`, `S line`.
- Route screenshots, home metro station, normal route, departure time, backup route, or commute reminders.

Natural trigger examples:

- `我下周有课，帮我看米兰罢工会不会影响通勤`
- `明天去 Bocconi 地铁会不会停？`
- `ATM sciopero 会影响我 10:30 上课吗？`
- `这是我的通勤截图，帮我判断罢工日怎么走`
- `我家在 Tolstoj，下周课表如下，帮我看每天几点出门`

If the user continues asking about the same timetable, route, strike, or reminder after an initial commute plan, keep using this skill's commute context. Follow-up examples include `那如果 M4 停了呢`, `帮我换一条路线`, `明天几点出门`, `给我设置提醒`, and `这个风险为什么是高`.

## Priority Gates

These gates override every other instruction:

- If the user asks for commute/strike planning but the minimum commute profile is incomplete, stop and ask only for the missing information.
- Minimum commute profile:
  1. home location, such as address, neighborhood, metro station, dorm, or map pin,
  2. class timetable with weekday/date, start time, and course name,
  3. normal route or normal commute mode, such as `M4 Tolstoj -> Santa Sofia -> walk`,
  4. destination confirmation; default is Bocconi only if the user mentions Bocconi or this skill has an explicit saved profile.
- If no timetable is present in the current message or explicit saved profile, do not check MIT/ATM/Trenord/web_search, do not output risk, and do not create class reminders. Ask for the timetable first.
- If no home or normal route is present, do not output a generic strike scan. Ask for the missing home/route first.
- A route screenshot is not a timetable. A home location is not a timetable.
- Weekly timetable reminder automations are not commute analyses. When they run, only ask the user to return to the main conversation and upload/paste next week's timetable.

Default missing-profile prompt:

```text
可以，我先帮你建通勤档案。要判断罢工会不会影响你，还差这些信息：

1. 你住在哪个地铁站/街区附近？
2. 下周哪几天上课、几点开始、课程名是什么？
3. 平时怎么去 Bocconi？可以发路线截图，或写成 M4 Tolstoj -> Santa Sofia -> 步行。

补完后我再查本周交通风险，给你每天几点出门、是否需要备选路线和提醒。
```

If only one field is missing, ask only that field.

## Fresh Transport Check

For every user request about strikes, delays, suspensions, reduced service, or route availability:

- Re-check current sources in that turn. Do not reuse previous answers or cached conclusions as current proof.
- Use Milan local time (`Europe/Rome`) for dates, weekdays, "today", "tomorrow", and "next week".
- If a source cannot be read, say so briefly and continue with the next reliable source. Do not expose technical SSL/Python details.

Read `references/transport-sources.md` when checking sources or deciding source priority.

Source priority:

1. MIT official strike calendar.
2. ATM Milano InfoTraffico.
3. Trenord notices.
4. Commissione Garanzia Sciopero.
5. The Italy Strike only as a secondary summary.
6. Web search as a fallback cross-check.

Source labels must be honest:

- `MIT: 已查` only if MIT was successfully read.
- `ATM: 已查` only if ATM or reliable ATM-related results were checked.
- If MIT RSS/certificate fails, write `MIT: 未成功读取；已改用 ATM/Trenord/Commissione/搜索结果交叉判断`.
- Do not say "多渠道交叉检索" unless multiple sources were actually checked.

## Route-Risk Logic

Risk levels:

- `低`: no relevant transport issue found for the user's class date, location, and route.
- `中`: Milano/Lombardia/ATM/Trenord/TPL watchlist exists, but it does not clearly hit the user's line or class commute window.
- `高`: a confirmed strike or disruption overlaps the user's class commute operator, route, mode, line, or commute time.

Matching rules:

- Confirmed ATM strike + user route uses metro, tram, bus, filobus, or ATM lines `M1`-`M5` => high.
- Confirmed ATM strike + route mentions a specific ATM line such as `M4`, `tram 15`, `bus 90/91` => high.
- Confirmed Trenord/rail strike + route uses Trenord, Passante, or `S` lines => high.
- Do not downgrade a confirmed overlapping strike just because partial service may run. It is still a high-risk planning event.
- On high-risk strike days, do not present the affected normal route as the recommended plan. Label it `平时路线：不稳/不建议依赖`.
- If ATM is affected, do not recommend ATM metro/tram/bus as the primary backup unless a reliable source gives a guaranteed service window. If such a window exists, explain it plainly, e.g. `公告写早高峰前为保证服务时段，所以可提前到校`.
- Prefer backup actions that do not rely on the affected operator: travel before the guaranteed window ends, bike/share-bike, walking segments, taxi/ride-hail, or arriving early and waiting near campus.
- Do not give the normal commute duration as the strike-day duration. Use conditional wording, e.g. `M4 若正常约 27-30 分钟；替代方案以实时导航为准`.

## Google Maps Links

This skill does not need Google Maps API or user API keys.

Every class-day card must include a Google Maps Markdown link:

```text
[打开 Google Maps 导航](https://www.google.com/maps/dir/?api=1&origin={origin}&destination=Bocconi%20University%2C%20Via%20Roberto%20Sarfatti%2025%2C%20Milano&travelmode=transit)
```

Rules:

- Do not paste long bare URLs.
- Do not write `导航：同上`, `需要时我可以发`, or omit the link.
- If multiple class days use the same route, repeat the link in every class-day card.
- Do not promise that the link can pre-set a future public-transit departure time. It is mainly for final real-time route checking.
- Do not auto-open Google Maps or the browser unless the user explicitly asks in the main conversation.

## Output Format

Codex answers should stay compact and scannable. Use exactly three sections for weekly commute answers:

```text
## 本周概览

- **风险**：低/中/高
- **原因**：一句话说明
- **来源**：MIT/ATM/辅助源状态，最多一行

## 每日通勤

### 周一 | Course

- **时间**：10:30-12:00
- **风险**：低/中/高
- **出门**：9:40-9:45
- **路线**：M4 Tolstoj -> Santa Sofia -> 步行
- **耗时**：约 27 分钟
- **注意**：一句话
- **导航**：[打开 Google Maps 导航](URL)

## 下一步

- 已创建本周出门提醒。
- 已创建每周日 17:00 课表提醒。
- 不需要的话可以在“自动任务”里暂停或删除。
```

Do not use code blocks, wide tables, or long source sections. Put one blank line between class-day cards.

High-risk strike-day card:

```text
### 周五 | Corporate Finance

- **时间**：10:30-12:00
- **风险**：高
- **原因**：ATM 罢工覆盖上课通勤时段，常用 M4 不稳
- **平时路线**：M4 Tolstoj -> Santa Sofia -> 步行到 Bocconi；不建议依赖
- **主方案 A**：若公告有保证服务窗口，提前坐 M4 到校，在学校附近等课
- **主方案 B**：不想早到就不要依赖 M4/tram/bus，改骑车、共享单车、打车或步行组合
- **出门**：方案 A 按保证窗口提前到校；方案 B 按实时导航多留 20-30 分钟
- **耗时**：M4 若正常约 27-30 分钟；替代方案以实时导航为准
- **注意**：不要把 tram/bus 当可靠备选；它们也可能受 ATM 罢工影响
- **导航**：[打开 Google Maps 导航](URL)
```

## Codex Reminder Behavior

When Codex automation tooling is available, create reminders by default after a valid weekly commute plan. Do not ask first. If the user says `取消提醒`, help cancel, pause, or delete the relevant automations.

Before creating, updating, viewing, or deleting reminders/automations in Codex, use the Codex automation tool exposed in the app. Prefer heartbeat automations attached to the current thread unless the user explicitly asks for standalone background jobs.

Read `references/codex-product.md` before changing reminder strategy.

Reminder strategy:

- Low-risk class day: previous evening + departure-minus-15-minutes.
- Medium/high-risk class day: previous evening + departure-minus-2-hours + departure-minus-15-minutes.
- First valid setup: create a recurring Sunday 17:00 timetable-upload reminder.
- If a new high-risk transport issue appears in a later re-check, update the next relevant reminder and tell the user what changed.

Reminder copy:

- Keep titles under 20 Chinese characters.
- Keep bodies short, like notifications.
- Do not include long Google Maps URLs.
- Do not tell the user to reply inside an automation run.
- Do not open Google Maps/browser from automation.
- Reminders should tell the user what to do next, not reprint the whole weekly report.

Templates:

- Weekly title: `每周课表提醒`
- Weekly body: `该发下周课表啦。回到主对话上传/粘贴课表；如果住址或通勤路线有变化，也一起告诉我。`
- Previous evening title: `周一通勤提醒`
- Previous evening body: `明天 10:30 有 Corporate Finance。建议 9:45 前出门；出发前自行复查地图/ATM。`
- Two-hour check title: `周一交通复查`
- Two-hour check body: `今天通勤有交通风险。请自行检查 ATM/Google Maps；如常用线路异常，按实时导航改线。`
- Departure title: `周一出门提醒`
- Departure body: `该准备出门了。10:30 Corporate Finance；预计约 27 分钟，自行检查实时路况。`

If automation tooling is not available, say it cannot create reminders and provide compact reminder copy.

## Codex Product Notes

This Codex version is allowed to go beyond the Marvis prototype:

- Use live web checks for unstable transport facts whenever the user asks for current or future commute risk.
- Use Codex automations for recurring timetable nudges and pre-class commute checks when available.
- Keep Google Maps as a user-clicked link; do not auto-open browser windows unless explicitly requested.
- If the user wants a demo scenario, clearly separate it from live-current judgment in internal reasoning, but avoid putting "demo mode" or fake-date disclaimers into a student-facing answer unless the user asks for them.
