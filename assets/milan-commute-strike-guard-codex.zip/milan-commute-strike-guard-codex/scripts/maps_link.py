#!/usr/bin/env python3
"""Generate a Google Maps directions link without using an API key."""

from __future__ import annotations

import argparse
import urllib.parse


DEFAULT_DESTINATION = "Bocconi University, Via Roberto Sarfatti 25, Milano"


def build_maps_link(origin: str, destination: str = DEFAULT_DESTINATION, mode: str = "transit") -> str:
    params = {
        "api": "1",
        "origin": origin,
        "destination": destination,
        "travelmode": mode,
    }
    return "https://www.google.com/maps/dir/?" + urllib.parse.urlencode(params)


def main() -> int:
    parser = argparse.ArgumentParser(description="Build a Google Maps directions URL.")
    parser.add_argument("--origin", required=True)
    parser.add_argument("--destination", default=DEFAULT_DESTINATION)
    parser.add_argument("--mode", default="transit", choices=["transit", "walking", "driving", "bicycling"])
    args = parser.parse_args()
    print(build_maps_link(args.origin, args.destination, args.mode))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
