#!/usr/bin/env python3
"""Create a weekly Bocconi commute plan from profile, timetable, and alerts JSON."""

from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import sys
import urllib.parse


DEFAULT_DESTINATION = "Bocconi University, Via Roberto Sarfatti 25, Milano"
RISK_ORDER = {"low": 0, "medium": 1, "high": 2}
RISK_LABEL_ZH = {"low": "低", "medium": "中", "high": "高"}


def load_json(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def build_maps_link(origin: str, destination: str = DEFAULT_DESTINATION) -> str:
    params = {
        "api": "1",
        "origin": origin,
        "destination": destination,
        "travelmode": "transit",
    }
    return "https://www.google.com/maps/dir/?" + urllib.parse.urlencode(params)


def extract_route_keywords(profile: dict) -> list[str]:
    explicit = profile.get("normal_route_keywords") or []
    text = " ".join([profile.get("normal_route", ""), " ".join(explicit)])
    patterns = [
        r"\bM[1-5]\b",
        r"\bS\d{1,2}\b",
        r"\btram\s*\d+\b",
        r"\bbus\s*\d+\b",
        r"\b(ATM|Trenord|Passante|metro|metropolitana|tram|bus|filobus|Romolo)\b",
    ]
    found: list[str] = []
    for pattern in patterns:
        for match in re.findall(pattern, text, flags=re.IGNORECASE):
            value = match if isinstance(match, str) else match[0]
            normalized = re.sub(r"\s+", " ", value.strip())
            if normalized and normalized.lower() not in {item.lower() for item in found}:
                found.append(normalized)
    return found


def normalize_date(date_text: str) -> str | None:
    if not date_text:
        return None
    for fmt in ("%Y-%m-%d", "%d/%m/%Y"):
        try:
            return dt.datetime.strptime(date_text, fmt).date().isoformat()
        except ValueError:
            continue
    return None


def text_dates(text: str) -> set[str]:
    dates: set[str] = set()
    for yyyy, mm, dd in re.findall(r"\b(\d{4})-(\d{2})-(\d{2})\b", text):
        dates.add(f"{yyyy}-{mm}-{dd}")
    for dd, mm, yyyy in re.findall(r"\b(\d{1,2})/(\d{1,2})/(\d{4})\b", text):
        try:
            dates.add(dt.date(int(yyyy), int(mm), int(dd)).isoformat())
        except ValueError:
            continue
    return dates


def alert_text(alert: dict) -> str:
    parts = [
        str(alert.get("date", "")),
        str(alert.get("title", "")),
        str(alert.get("description", "")),
        " ".join(str(item) for item in alert.get("affected_keywords", [])),
        " ".join(str(item) for item in alert.get("affected_lines", [])),
    ]
    return " ".join(parts)


def classify_alert_for_route(alert: dict, route_keywords: list[str]) -> str:
    explicit_risk = str(alert.get("risk", "")).lower()
    text = alert_text(alert).lower()
    keywords = [keyword.lower() for keyword in route_keywords]
    route_uses_atm = any(
        keyword.startswith(("m1", "m2", "m3", "m4", "m5"))
        or "metro" in keyword
        or "tram" in keyword
        or "bus" in keyword
        or "filobus" in keyword
        or "atm" in keyword
        for keyword in keywords
    )
    route_uses_rail = any(
        "trenord" in keyword
        or "passante" in keyword
        or keyword.startswith(("s1", "s2", "s5", "s6", "s9", "s13"))
        for keyword in keywords
    )

    if any(keyword and keyword in text for keyword in keywords):
        return "high"
    if route_uses_atm and any(word in text for word in ["atm", "tpl", "trasporto pubblico", "metro", "metropolitana", "tram", "bus", "filobus"]):
        return "high"
    if route_uses_rail and any(word in text for word in ["trenord", "ferroviario", "passante", "regionale"]):
        return "high"
    if any(word in text for word in ["atm", "trenord", "tpl", "trasporto pubblico", "ferroviario", "metro", "tram", "bus"]):
        return "medium"
    if explicit_risk in RISK_ORDER:
        return explicit_risk
    return "medium"


def match_alerts(klass: dict, alerts: list[dict], route_keywords: list[str]) -> list[dict]:
    class_date = normalize_date(klass.get("date", ""))
    matches = []
    for alert in alerts:
        haystack = alert_text(alert)
        alert_dates = text_dates(haystack)
        if class_date and alert_dates and class_date not in alert_dates:
            continue
        if class_date and not alert_dates and normalize_date(str(alert.get("date", ""))) != class_date:
            continue
        risk = classify_alert_for_route(alert, route_keywords)
        enriched = dict(alert)
        enriched["route_match_risk"] = risk
        matches.append(enriched)
    return matches[:6]


def highest_risk(matches: list[dict]) -> str:
    risk = "low"
    for alert in matches:
        candidate = alert.get("route_match_risk") or alert.get("risk") or "medium"
        candidate = "medium" if candidate in {"watchlist", "likely", "confirmed"} else str(candidate).lower()
        if candidate not in RISK_ORDER:
            candidate = "medium"
        if RISK_ORDER[candidate] > RISK_ORDER[risk]:
            risk = candidate
    return risk


def subtract_minutes(time_text: str, minutes: int) -> str:
    parsed = dt.datetime.strptime(time_text, "%H:%M")
    return (parsed - dt.timedelta(minutes=minutes)).strftime("%H:%M")


def make_plan(profile: dict, klass: dict, alerts: list[dict]) -> dict:
    route_keywords = extract_route_keywords(profile)
    matched = match_alerts(klass, alerts, route_keywords)
    risk = highest_risk(matched)
    normal_minutes = int(profile.get("normal_commute_minutes", 50))
    buffer_minutes = {"low": 15, "medium": 30, "high": 45}[risk]
    start_time = klass["start_time"]
    depart = subtract_minutes(start_time, normal_minutes + buffer_minutes)
    origin = profile.get("home_location", "home")
    destination = profile.get("school_location", DEFAULT_DESTINATION)
    maps_link = build_maps_link(origin, destination)

    if risk == "low":
        reminders = [
            f"前一晚：明天 {start_time} 在 Bocconi 上课，暂无明显交通风险。建议 {depart} 出门。",
            "出门前15分钟：现在该准备出门了。自行检查 Google Maps/ATM 实时路线。",
        ]
        route_usable = "大概率可用"
    else:
        reminders = [
            f"前一晚：明天 {start_time} 在 Bocconi 上课，存在{RISK_LABEL_ZH[risk]}风险交通提醒。先准备备选路线。",
            f"出门前2小时：自行检查 Google Maps/ATM 路线。如果常用线路异常，按实时导航改线。",
            f"出门前15分钟：现在该出门了。今天按 {normal_minutes + buffer_minutes} 分钟预算，别压线。",
        ]
        route_usable = "需出门前复查"

    return {
        "date": klass.get("date") or klass.get("weekday"),
        "weekday": klass.get("weekday"),
        "course": klass.get("course", "class"),
        "start_time": start_time,
        "end_time": klass.get("end_time"),
        "risk": risk,
        "reason": summarize_reason(matched, route_keywords),
        "normal_route": profile.get("normal_route", f"{origin} -> {destination}"),
        "normal_route_likely_usable": route_usable,
        "recommended_departure": depart,
        "normal_commute_minutes": normal_minutes,
        "buffer_minutes": buffer_minutes,
        "maps_link": maps_link,
        "matched_alerts": matched,
        "reminders": reminders,
    }


def overall_risk(plans: list[dict]) -> str:
    risk = "low"
    for plan in plans:
        candidate = plan.get("risk", "low")
        if RISK_ORDER.get(candidate, 0) > RISK_ORDER[risk]:
            risk = candidate
    return risk


def render_markdown(payload: dict) -> str:
    plans = payload["plans"]
    risk = overall_risk(plans)
    source_note = "按输入 alerts 与常用路线关键词判断；真实使用时必须重新查当前来源。"
    if risk == "low":
        reason = "未发现与课程日期和常用路线重叠的交通风险。"
    elif risk == "medium":
        reason = "存在交通观察项，但尚未明确命中课程路线或通勤时间。"
    else:
        reason = "存在确认交通风险，且与课程路线或通勤时间重叠。"

    lines = [
        "## 本周概览",
        "",
        f"- **风险**：{RISK_LABEL_ZH[risk]}",
        f"- **原因**：{reason}",
        f"- **来源**：{source_note}",
        "",
        "## 每日通勤",
        "",
    ]

    for plan in plans:
        label = RISK_LABEL_ZH[plan["risk"]]
        lines.extend(
            [
                f"### {plan.get('weekday') or plan.get('date')} | {plan['course']}",
                "",
                f"- **时间**：{plan['start_time']}" + (f"-{plan['end_time']}" if plan.get("end_time") else ""),
                f"- **风险**：{label}",
            ]
        )
        if plan["risk"] == "high":
            lines.extend(
                [
                    f"- **原因**：{plan['reason']}",
                    f"- **平时路线**：{plan['normal_route']}；不建议依赖",
                    "- **主方案 A**：若公告有保证服务窗口，提前到校，在学校附近等课",
                    "- **主方案 B**：不想早到就改骑车、共享单车、打车或步行组合",
                    f"- **出门**：{plan['recommended_departure']} 前完成出发决策，按实时导航走",
                    "- **耗时**：平时路线若正常约 27-30 分钟；替代方案以实时导航为准",
                    "- **注意**：不要把受影响的 metro/tram/bus 当默认可靠备选",
                ]
            )
        else:
            lines.extend(
                [
                    f"- **出门**：{plan['recommended_departure']}",
                    f"- **路线**：{plan['normal_route']}",
                    f"- **耗时**：约 {plan['normal_commute_minutes']} 分钟",
                    f"- **注意**：{plan['reason']}",
                ]
            )
        lines.extend(
            [
                f"- **导航**：[打开 Google Maps 导航]({plan['maps_link']})",
                "",
            ]
        )

    lines.extend(
        [
            "## 下一步",
            "",
            "- 能创建 Codex 自动化时，默认创建课表提醒和出门提醒。",
            "- 不需要的话告诉我「取消通勤提醒」。",
        ]
    )
    return "\n".join(lines)


def summarize_reason(matches: list[dict], route_keywords: list[str]) -> str:
    if not matches:
        return "未发现与当天和常用路线明确相关的 Milan/ATM/Trenord 交通风险。"
    first = matches[0]
    source = first.get("source", "transport source")
    title = first.get("title", "transport alert")
    keywords = ", ".join(route_keywords) if route_keywords else "未提供常用路线关键词"
    return f"{source} 有相关提醒：{title}；已按常用路线关键词 [{keywords}] 判断。"


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate a Milan student weekly commute plan.")
    parser.add_argument("input_json")
    parser.add_argument("--pretty", action="store_true")
    parser.add_argument("--markdown", action="store_true")
    args = parser.parse_args()

    data = load_json(args.input_json)
    profile = data.get("profile", {})
    timetable = data.get("timetable", [])
    alerts = data.get("alerts", [])
    if not timetable:
        print("input_json must include timetable", file=sys.stderr)
        return 2

    payload = {
        "profile": profile,
        "route_keywords": extract_route_keywords(profile),
        "plans": [make_plan(profile, klass, alerts) for klass in timetable],
    }
    if args.markdown:
        print(render_markdown(payload))
    else:
        print(json.dumps(payload, ensure_ascii=False, indent=2 if args.pretty else None))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
